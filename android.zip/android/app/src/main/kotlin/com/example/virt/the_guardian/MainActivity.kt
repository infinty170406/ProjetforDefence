package com.example.virt.the_guardian

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
