import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'widgets/laptop_dashboard_mockup.dart';
import 'widgets/smartphone_app_mockup.dart';

class WebLandingScreen extends StatefulWidget {
  const WebLandingScreen({super.key});

  @override
  State<WebLandingScreen> createState() => _WebLandingScreenState();
}

class _WebLandingScreenState extends State<WebLandingScreen> {
  final ScrollController _scrollController = ScrollController();
  bool _scrolled = false;
  String _mockupTab = 'parent'; // 'parent' or 'child'
  int? _expandedFaqIndex;

  final List<Map<String, dynamic>> _features = [
    {
      'title': "Orchestrateur IA",
      'description': "Analyse en temps réel les comportements numériques pour détecter les risques sans espionner. Il génère des bilans bienveillants et des alertes contextuelles pour guider vos enfants.",
      'icon': Icons.psychology,
    },
    {
      'title': "Géolocalisation & Zones Scolaires",
      'description': "Suivez la position géographique de vos enfants et configurez des zones de sécurité géographiques (école, maison) avec alertes automatiques d'arrivée et de départ.",
      'icon': Icons.map,
    },
    {
      'title': "Limites de Temps d'Écran",
      'description': "Définissez des limites quotidiennes de temps d'écran globales ou par catégories d'applications (Réseaux Sociaux, Jeux). L'appareil se verrouille automatiquement dès que le quota est atteint.",
      'icon': Icons.access_time_filled,
    },
    {
      'title': "Blocage de Contenu Dynamique",
      'description': "Intercepte instantanément l'accès aux sites ou applications non autorisés (catégories sensibles comme les jeux d'argent, violence ou pornographie) grâce au moteur d'analyse réseau.",
      'icon': Icons.lock,
    },
    {
      'title': "Protection Native Inviolable",
      'description': "Intègre en profondeur les services système Android (AccessibilityService & DeviceAdmin) pour résister à toute désinstallation non autorisée, fermeture forcée ou contournement par VPN.",
      'icon': Icons.shield,
    },
  ];

  final List<Map<String, dynamic>> _testimonials = [
    {
      'name': "Valérie M.",
      'role': "Maman de Lucas (15 ans)",
      'comment': "Depuis que nous avons installé Guardian, les disputes à propos du temps d'écran ont totalement disparu. Lucas sait exactement de combien de temps il dispose, et l'Orchestrateur IA m'alerte s'il y a un réel problème.",
      'avatar': "V",
      'color': const Color(0xFF6366F1),
    },
    {
      'name': "Stéphane T.",
      'role': "Papa de Emma (12 ans)",
      'comment': "La fonction 'Zone Scolaire' est rassurante. Je reçois une notification discrète à son arrivée au collège. Le fait que l'application soit inviolable sur Android évite qu'elle ne la désactive par accident.",
      'avatar': "S",
      'color': const Color(0xFF0EA5E9),
    },
    {
      'name': "Isabelle D.",
      'role': "Maman de Léa (14 ans) et Théo (9 ans)",
      'comment': "J'apprécie l'Orchestrateur IA qui n'est pas un bête outil d'espionnage mais propose une supervision intelligente. C'est parfait pour accompagner mes enfants vers l'autonomie en toute sécurité.",
      'avatar': "I",
      'color': const Color(0xFF10B981),
    },
  ];

  final List<Map<String, String>> _faqs = [
    {
      'q': "Comment fonctionne l'Orchestrateur IA ?",
      'a': "L'Orchestrateur IA analyse en arrière-plan l'activité des applications et la sécurité globale de l'appareil de votre enfant. Plutôt que de simplement bloquer et fliquer de manière aveugle, il détecte les anomalies ou les usages abusifs, et envoie des alertes claires ainsi que des conseils d'accompagnement sur le dashboard parent."
    },
    {
      'q': "Mon enfant peut-il désinstaller ou contourner l'application ?",
      'a': "Non. Grâce à l'utilisation des APIs natives du système Android (telles que le gestionnaire d'administration de l'appareil 'DeviceAdmin' et le service d'accessibilité 'AccessibilityService'), Guardian se verrouille au cœur du système. Toute tentative de désinstallation, de modification du GPS ou de contournement nécessite le mot de passe parental."
    },
    {
      'q': "Quelles sont les fonctionnalités de blocage disponibles ?",
      'a': "Guardian propose le blocage dynamique par catégories de sites web (par exemple, les jeux d'argent, le contenu adulte, ou la violence), la restriction d'applications spécifiques, et le blocage complet de l'appareil selon des tranches horaires (mode école, heure du coucher) ou suite à un dépassement du temps autorisé."
    },
    {
      'q': "La géolocalisation fonctionne-t-elle en arrière-plan ?",
      'a': "Oui, la géolocalisation suit en temps réel la position de l'appareil de manière optimisée pour préserver la batterie. Vous pouvez définir des zones géographiques de confiance (par exemple 'École' ou 'Maison') et être notifié automatiquement dès que votre enfant y pénètre ou en sort."
    },
    {
      'q': "Quels types d'appareils sont supportés ?",
      'a': "Notre application est optimisée pour les smartphones et tablettes des enfants sous Android (avec intégration native poussée) et propose une console de gestion web (Orchestrateur Dashboard) accessible aux parents depuis n'importe quel ordinateur ou smartphone."
    }
  ];

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(() {
      if (_scrollController.offset > 50) {
        if (!_scrolled) {
          setState(() {
            _scrolled = true;
          });
        }
      } else {
        if (_scrolled) {
          setState(() {
            _scrolled = false;
          });
        }
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToSection(double offset) {
    _scrollController.animateTo(
      offset,
      duration: const Duration(milliseconds: 600),
      curve: Curves.easeInOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final isMobile = width < 1000;

    return Scaffold(
      backgroundColor: const Color(0xFFF4F6FF),
      body: Stack(
        children: [
          // Background Glows
          Positioned(
            top: -200,
            left: -200,
            child: Container(
              width: 600,
              height: 600,
              decoration: BoxDecoration(
                color: const Color(0xFF4F46E5).withOpacity(0.08),
                shape: BoxShape.circle,
              ),
            ),
          ),
          Positioned(
            top: 400,
            right: -300,
            child: Container(
              width: 700,
              height: 700,
              decoration: BoxDecoration(
                color: const Color(0xFF14B8A6).withOpacity(0.06),
                shape: BoxShape.circle,
              ),
            ),
          ),

          // Main Scrollable Content
          SingleChildScrollView(
            controller: _scrollController,
            child: Column(
              children: [
                const SizedBox(height: 120), // Spacing for floating nav
                _buildHero(isMobile, width),
                _buildStatsSection(isMobile),
                _buildFeaturesSection(isMobile),
                _buildWhyUsSection(isMobile),
                _buildTestimonialsSection(isMobile),
                _buildFaqSection(isMobile),
                _buildCtaSection(isMobile),
                _buildFooter(isMobile),
              ],
            ),
          ),

          // Floating Navigation Bar
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: _buildNavBar(isMobile),
          ),
        ],
      ),
    );
  }

  Widget _buildNavBar(bool isMobile) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      padding: EdgeInsets.symmetric(horizontal: 40, vertical: _scrolled ? 16 : 24),
      decoration: BoxDecoration(
        color: _scrolled ? Colors.white.withOpacity(0.85) : Colors.transparent,
        border: Border(
          bottom: BorderSide(
            color: _scrolled ? const Color(0xFFE2E8F0)!.withOpacity(0.4) : Colors.transparent,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Logo
          InkWell(
            onTap: () => _scrollToSection(0),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF4F46E5), Color(0xFF14B8A6)],
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.shield, color: Colors.white, size: 20),
                ),
                const SizedBox(width: 10),
                const Text(
                  "Guardian",
                  style: TextStyle(
                    color: Color(0xFF0F172A),
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    fontFamily: 'Outfit',
                  ),
                ),
              ],
            ),
          ),

          // Nav links
          if (!isMobile)
            Row(
              children: [
                _buildNavLink("Fonctionnalités", () => _scrollToSection(900)),
                _buildNavLink("Aperçu App", () => _scrollToSection(1700)),
                _buildNavLink("Pourquoi Nous", () => _scrollToSection(2600)),
                _buildNavLink("Témoignages", () => _scrollToSection(3300)),
                _buildNavLink("FAQ", () => _scrollToSection(4000)),
              ],
            ),

          // CTA
          ElevatedButton(
            onPressed: () => context.push('/login/parent'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF4F46E5),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
              elevation: 0,
            ),
            child: const Text(
              "Espace Parent",
              style: TextStyle(fontFamily: 'Outfit', fontWeight: FontWeight.bold, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavLink(String text, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(right: 28),
      child: InkWell(
        onTap: onTap,
        child: Text(
          text,
          style: TextStyle(
            color: const Color(0xFF475569),
            fontSize: 12,
            fontWeight: FontWeight.bold,
            fontFamily: 'Outfit',
          ),
        ),
      ),
    );
  }

  Widget _buildHero(bool isMobile, double width) {
    final double scaling = isMobile ? 1.0 : (width > 1200 ? 1.0 : width / 1200);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 40),
      child: Column(
        children: [
          if (isMobile) ...[
            FadeInUp(child: _buildHeroText(isMobile)),
            const SizedBox(height: 40),
            FadeInUp(delay: const Duration(milliseconds: 200), child: _buildInteractiveMockupArea(scaling)),
          ] else ...[
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 5,
                  child: FadeInUp(child: _buildHeroText(isMobile)),
                ),
                const SizedBox(width: 40),
                Expanded(
                  flex: 6,
                  child: FadeInUp(delay: const Duration(milliseconds: 200), child: _buildInteractiveMockupArea(scaling)),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildHeroText(bool isMobile) {
    return Column(
      crossAxisAlignment: isMobile ? CrossAxisAlignment.center : CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          decoration: BoxDecoration(
            color: const Color(0xFF4F46E5).withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.auto_awesome, color: Color(0xFF4F46E5), size: 14),
              SizedBox(width: 8),
              Text(
                "Contrôle Parental Nouvelle Génération",
                style: TextStyle(
                  color: Color(0xFF4F46E5),
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Outfit',
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        Text(
          "Sécurité Système Native\n& IA Bienveillante",
          textAlign: isMobile ? TextAlign.center : TextAlign.start,
          style: const TextStyle(
            color: Color(0xFF0F172A),
            fontSize: 48,
            fontWeight: FontWeight.w900,
            fontFamily: 'Outfit',
            height: 1.1,
          ),
        ),
        const SizedBox(height: 24),
        Text(
          "Découvrez Guardian, le contrôle parental intelligent et inviolable pour accompagner vos enfants en toute sécurité. Doté d'un Orchestrateur IA bienveillant et d'une sécurité système robuste.",
          textAlign: isMobile ? TextAlign.center : TextAlign.start,
          style: TextStyle(
            color: const Color(0xFF475569),
            fontSize: 16,
            height: 1.6,
            fontFamily: 'Outfit',
          ),
        ),
        const SizedBox(height: 36),
        Row(
          mainAxisAlignment: isMobile ? MainAxisAlignment.center : MainAxisAlignment.start,
          children: [
            ElevatedButton(
              onPressed: () => _scrollToSection(1700),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF4F46E5),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 20),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                elevation: 0,
              ),
              child: const Text("Découvrir la démo", style: TextStyle(fontWeight: FontWeight.bold)),
            ),
            const SizedBox(width: 16),
            OutlinedButton(
              onPressed: () => context.push('/login/parent'),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Color(0xFF4F46E5)),
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 20),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
              ),
              child: const Text("Console Parent", style: TextStyle(color: Color(0xFF4F46E5), fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildInteractiveMockupArea(double scale) {
    return Column(
      children: [
        // Tabs
        Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: const Color(0xFFE2E8F0)!),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildMockupTabButton('parent', "Console Laptop (Parent)"),
              _buildMockupTabButton('child', "Application Smartphone (Enfant)"),
            ],
          ),
        ),
        const SizedBox(height: 24),

        // Display Mockup
        Center(
          child: Transform.scale(
            scale: scale,
            alignment: Alignment.topCenter,
            child: SizedBox(
              height: 620,
              child: _mockupTab == 'parent'
                  ? const Center(child: LaptopDashboardMockup())
                  : const Center(child: SmartphoneAppMockup()),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMockupTabButton(String tab, String label) {
    final active = _mockupTab == tab;
    return InkWell(
      onTap: () {
        setState(() {
          _mockupTab = tab;
        });
      },
      borderRadius: BorderRadius.circular(30),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: BoxDecoration(
          color: active ? const Color(0xFF4F46E5) : Colors.transparent,
          borderRadius: BorderRadius.circular(30),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: active ? Colors.white : const Color(0xFF475569),
            fontSize: 11,
            fontWeight: FontWeight.bold,
            fontFamily: 'Outfit',
          ),
        ),
      ),
    );
  }

  Widget _buildStatsSection(bool isMobile) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 60),
      child: Wrap(
        spacing: 24,
        runSpacing: 24,
        alignment: WrapAlignment.center,
        children: [
          AnimatedHoverCard(child: _buildStatCard("Moteur IA Actif", "Analyse sémantique & contextuelle")),
          AnimatedHoverCard(child: _buildStatCard("Sécurité Native", "100% inviolable sur Android")),
          AnimatedHoverCard(child: _buildStatCard("Temps Réel", "Position & notifications GPS")),
          AnimatedHoverCard(child: _buildStatCard("Accompagnement", "Lien parent-enfant renforcé")),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String desc) {
    return Container(
      width: 220,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE2E8F0)!.withOpacity(0.5)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            title,
            style: const TextStyle(color: Color(0xFF0F172A), fontSize: 14, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            desc,
            textAlign: TextAlign.center,
            style: TextStyle(color: const Color(0xFF64748B), fontSize: 11),
          ),
        ],
      ),
    );
  }

  Widget _buildFeaturesSection(bool isMobile) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 80),
      color: Colors.white,
      child: Column(
        children: [
          const Text(
            "FONCTIONNALITÉS CLÉS",
            style: TextStyle(color: Color(0xFF4F46E5), fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 1.5),
          ),
          const SizedBox(height: 12),
          const Text(
            "Une protection intelligente & complète",
            style: TextStyle(color: Color(0xFF0F172A), fontSize: 32, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 48),

          // Features grid
          Wrap(
            spacing: 24,
            runSpacing: 24,
            alignment: WrapAlignment.center,
            children: _features.map((f) => AnimatedHoverCard(child: _buildFeatureCard(f))).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureCard(Map<String, dynamic> f) {
    return Container(
      width: 320,
      height: 220,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFE2E8F0)!.withOpacity(0.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFF4F46E5).withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(f['icon'] as IconData, color: const Color(0xFF4F46E5), size: 20),
          ),
          const SizedBox(height: 16),
          Text(
            f['title'] as String,
            style: const TextStyle(color: Color(0xFF0F172A), fontSize: 15, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            f['description'] as String,
            style: TextStyle(color: const Color(0xFF64748B), fontSize: 11, height: 1.5),
          ),
        ],
      ),
    );
  }

  Widget _buildWhyUsSection(bool isMobile) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 80),
      child: Column(
        children: [
          const Text(
            "POURQUOI NOUS REJOINDRE ?",
            style: TextStyle(color: Color(0xFF14B8A6), fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 1.5),
          ),
          const SizedBox(height: 12),
          const Text(
            "Une armure inviolable au cœur du système",
            style: TextStyle(color: Color(0xFF0F172A), fontSize: 32, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: 800,
            child: Text(
              "Contrairement aux autres solutions facilement contournables, Guardian utilise les outils d'administration système natifs. L'enfant ne peut ni contourner par VPN, ni forcer l'arrêt, ni désinstaller l'application sans votre mot de passe parental. Le filtrage DNS fonctionne 24h/24, assurant une protection sans faille.",
              textAlign: TextAlign.center,
              style: TextStyle(color: const Color(0xFF475569), fontSize: 14, height: 1.6),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTestimonialsSection(bool isMobile) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 80),
      color: Colors.white,
      child: Column(
        children: [
          const Text(
            "TÉMOIGNAGES",
            style: TextStyle(color: Color(0xFF4F46E5), fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 1.5),
          ),
          const SizedBox(height: 12),
          const Text(
            "Ce que disent les parents",
            style: TextStyle(color: Color(0xFF0F172A), fontSize: 32, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 48),

          Wrap(
            spacing: 24,
            runSpacing: 24,
            alignment: WrapAlignment.center,
            children: _testimonials.map((t) => AnimatedHoverCard(child: _buildTestimonialCard(t))).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildTestimonialCard(Map<String, dynamic> t) {
    return Container(
      width: 320,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFE2E8F0)!.withOpacity(0.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(color: t['color'] as Color, shape: BoxShape.circle),
                child: Center(
                  child: Text(t['avatar'] as String, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(t['name'] as String, style: const TextStyle(color: Color(0xFF0F172A), fontSize: 12, fontWeight: FontWeight.bold)),
                  Text(t['role'] as String, style: const TextStyle(color: Colors.grey, fontSize: 10)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            t['comment'] as String,
            style: TextStyle(color: const Color(0xFF475569), fontSize: 11, height: 1.6, fontStyle: FontStyle.italic),
          ),
        ],
      ),
    );
  }

  Widget _buildFaqSection(bool isMobile) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 80),
      child: Column(
        children: [
          const Text(
            "FAQ",
            style: TextStyle(color: Color(0xFF14B8A6), fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 1.5),
          ),
          const SizedBox(height: 12),
          const Text(
            "Questions Fréquentes",
            style: TextStyle(color: Color(0xFF0F172A), fontSize: 32, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 48),

          Container(
            width: 800,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: const Color(0xFFE2E8F0)!),
            ),
            child: ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _faqs.length,
              separatorBuilder: (context, index) => Divider(color: const Color(0xFFE2E8F0)),
              itemBuilder: (context, index) {
                final faq = _faqs[index];
                final isExpanded = _expandedFaqIndex == index;
                return InkWell(
                  onTap: () {
                    setState(() {
                      _expandedFaqIndex = isExpanded ? null : index;
                    });
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              faq['q']!,
                              style: const TextStyle(color: Color(0xFF0F172A), fontSize: 14, fontWeight: FontWeight.bold),
                            ),
                            Icon(isExpanded ? Icons.expand_less : Icons.expand_more, color: Colors.grey),
                          ],
                        ),
                        if (isExpanded) ...[
                          const SizedBox(height: 12),
                          Text(
                            faq['a']!,
                            style: TextStyle(color: const Color(0xFF64748B), fontSize: 12, height: 1.6),
                          ),
                        ],
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCtaSection(bool isMobile) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 80),
      color: const Color(0xFF0F172A),
      width: double.infinity,
      child: Column(
        children: [
          const Text(
            "Prêt à protéger vos enfants ?",
            style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          const Text(
            "Configurez Guardian en quelques minutes et accédez au dashboard complet.",
            style: TextStyle(color: Colors.grey, fontSize: 14),
          ),
          const SizedBox(height: 36),

          Wrap(
            spacing: 16,
            runSpacing: 16,
            children: [
              ElevatedButton(
                onPressed: () => context.push('/login/parent'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF4F46E5),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 20),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                  elevation: 0,
                ),
                child: const Text("Accéder Console Parent", style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              OutlinedButton(
                onPressed: () => context.push('/login/admin'),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Colors.white),
                  padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 20),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                ),
                child: const Text("Accéder Console Administrateur", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFooter(bool isMobile) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 40),
      color: const Color(0xFF090B16),
      width: double.infinity,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            "© 2026 Guardian Parental Control. Tous droits réservés.",
            style: TextStyle(color: Colors.grey, fontSize: 11),
          ),
          Row(
            children: [
              Text("Mentions Légales", style: TextStyle(color: const Color(0xFF94A3B8), fontSize: 11)),
              const SizedBox(width: 20),
              Text("Politique de Confidentialité", style: TextStyle(color: const Color(0xFF94A3B8), fontSize: 11)),
            ],
          ),
        ],
      ),
    );
  }
}

class AnimatedHoverCard extends StatefulWidget {
  final Widget child;
  const AnimatedHoverCard({required this.child, super.key});

  @override
  State<AnimatedHoverCard> createState() => _AnimatedHoverCardState();
}

class _AnimatedHoverCardState extends State<AnimatedHoverCard> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        transform: Matrix4.identity()..translate(0.0, _isHovered ? -8.0 : 0.0),
        child: widget.child,
      ),
    );
  }
}

class FadeInUp extends StatelessWidget {
  final Widget child;
  final Duration delay;
  final Duration duration;

  const FadeInUp({
    required this.child,
    this.delay = Duration.zero,
    this.duration = const Duration(milliseconds: 800),
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: Future.delayed(delay),
      builder: (context, snapshot) {
        final show = snapshot.connectionState == ConnectionState.done || delay == Duration.zero;
        return TweenAnimationBuilder<double>(
          tween: Tween<double>(begin: 0.0, end: show ? 1.0 : 0.0),
          duration: duration,
          curve: Curves.easeOutCubic,
          builder: (context, value, child) {
            return Opacity(
              opacity: value,
              child: Transform.translate(
                offset: Offset(0.0, (1.0 - value) * 30.0),
                child: child,
              ),
            );
          },
          child: child,
        );
      },
    );
  }
}
