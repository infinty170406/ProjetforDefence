import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/services/api_service.dart';
import '../../core/services/notification_service.dart';

class WebLoginScreen extends StatefulWidget {
  final String type; // 'parent' or 'admin'
  const WebLoginScreen({super.key, required this.type});

  @override
  State<WebLoginScreen> createState() => _WebLoginScreenState();
}

class _WebLoginScreenState extends State<WebLoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _nameController = TextEditingController();

  bool _isSignUp = false;
  bool _isLoading = false;
  bool _obscurePassword = true;
  String? _errorMessage;
  bool _isDark = true;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    _nameController.dispose();
    super.dispose();
  }

  bool _isValidEmail(String email) =>
      RegExp(r'^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$')
          .hasMatch(email);

  Future<void> _handleAuth() async {
    setState(() {
      _errorMessage = null;
    });

    final email = _emailController.text.trim();
    final password = _passwordController.text;
    final name = _nameController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      setState(() {
        _errorMessage = "Veuillez remplir tous les champs.";
      });
      return;
    }

    if (!_isValidEmail(email)) {
      setState(() {
        _errorMessage = "Format d'adresse email invalide.";
      });
      return;
    }

    if (_isSignUp && password != _confirmPasswordController.text) {
      setState(() {
        _errorMessage = "Les mots de passe ne correspondent pas.";
      });
      return;
    }

    if (_isSignUp && name.isEmpty) {
      setState(() {
        _errorMessage = "Veuillez saisir votre nom complet.";
      });
      return;
    }

    setState(() => _isLoading = true);

    try {
      if (widget.type == 'admin') {
        // Admin Login
        await ApiService().loginWithEmailPassword(email, password);
        await NotificationService().syncToken();
        if (mounted) context.go('/admin/web');
      } else {
        if (_isSignUp) {
          // Parent Register
          await ApiService().registerWithEmailPassword(name, email, password);
          await NotificationService().syncToken();
          if (mounted) context.go('/otp-setup');
        } else {
          // Parent Login
          await ApiService().loginWithEmailPassword(email, password);
          await NotificationService().syncToken();
          if (mounted) context.go('/dashboard/web');
        }
      }
    } catch (e) {
      setState(() {
        _errorMessage = e is ApiException ? e.message : e.toString();
      });
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final title = widget.type == 'admin'
        ? 'Console Administration'
        : (_isSignUp ? 'Créer un compte Parent' : 'Espace Supervision Parent');

    final subtitle = widget.type == 'admin'
        ? 'Accès sécurisé réservé aux administrateurs réseau.'
        : (_isSignUp
            ? 'Commencez à protéger l\'environnement numérique de vos enfants.'
            : 'Connectez-vous pour accéder au tableau de bord.');

    final backgroundColor = _isDark ? const Color(0xFF020617) : const Color(0xFFF4F6FF);
    final cardColor = _isDark ? const Color(0xFF0B1329).withOpacity(0.8) : Colors.white.withOpacity(0.85);
    final textColor = _isDark ? Colors.white : const Color(0xFF1E293B);
    final subtextColor = _isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
    final borderColor = _isDark ? Colors.white.withOpacity(0.1) : const Color(0xFFE2E8F0)!;

    return Scaffold(
      backgroundColor: backgroundColor,
      body: Stack(
        children: [
          // Background glows
          Positioned(
            top: -200,
            left: -200,
            child: Container(
              width: 500,
              height: 500,
              decoration: BoxDecoration(
                color: const Color(0xFF4F46E5).withOpacity(_isDark ? 0.08 : 0.05),
                shape: BoxShape.circle,
              ),
            ),
          ),
          Positioned(
            bottom: -200,
            right: -200,
            child: Container(
              width: 500,
              height: 500,
              decoration: BoxDecoration(
                color: const Color(0xFF14B8A6).withOpacity(_isDark ? 0.08 : 0.05),
                shape: BoxShape.circle,
              ),
            ),
          ),

          // Theme Toggler
          Positioned(
            top: 24,
            right: 24,
            child: InkWell(
              onTap: () {
                setState(() {
                  _isDark = !_isDark;
                });
              },
              borderRadius: BorderRadius.circular(16),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _isDark ? const Color(0xFF0F172A) : Colors.white,
                  border: Border.all(color: borderColor),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                    ),
                  ],
                ),
                child: Icon(
                  _isDark ? Icons.wb_sunny : Icons.nightlight_round,
                  color: _isDark ? Colors.yellow : const Color(0xFF4F46E5),
                  size: 18,
                ),
              ),
            ),
          ),

          // Main Center Card
          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Container(
                width: 420,
                padding: const EdgeInsets.all(32),
                decoration: BoxDecoration(
                  color: cardColor,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: borderColor),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(_isDark ? 0.4 : 0.08),
                      blurRadius: 40,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Header Logo
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFF4F46E5), Color(0xFF14B8A6)],
                            ),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(Icons.shield, color: Colors.white, size: 20),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          "THE GUARDIAN",
                          style: TextStyle(
                            color: textColor,
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.5,
                            fontFamily: 'Outfit',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 32),

                    // Title & Subtitle
                    Text(
                      title,
                      style: TextStyle(
                        color: textColor,
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Outfit',
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: subtextColor,
                        fontSize: 12,
                        fontFamily: 'Outfit',
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 24),

                    // Error message
                    if (_errorMessage != null)
                      Container(
                        padding: const EdgeInsets.all(12),
                        margin: const EdgeInsets.only(bottom: 20),
                        decoration: BoxDecoration(
                          color: Colors.red.withOpacity(0.1),
                          border: Border.all(color: Colors.red.withOpacity(0.3)),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.error_outline, color: Colors.red, size: 16),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                _errorMessage!,
                                style: const TextStyle(color: Colors.red, fontSize: 11, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ],
                        ),
                      ),

                    // Fields
                    if (_isSignUp) ...[
                      _buildTextField(
                        controller: _nameController,
                        hint: "Nom complet",
                        icon: Icons.person_outline,
                        textColor: textColor,
                        subtextColor: subtextColor,
                        borderColor: borderColor,
                      ),
                      const SizedBox(height: 16),
                    ],

                    _buildTextField(
                      controller: _emailController,
                      hint: "Adresse email",
                      icon: Icons.email_outlined,
                      keyboardType: TextInputType.emailAddress,
                      textColor: textColor,
                      subtextColor: subtextColor,
                      borderColor: borderColor,
                    ),
                    const SizedBox(height: 16),

                    _buildTextField(
                      controller: _passwordController,
                      hint: "Mot de passe",
                      icon: Icons.lock_outline,
                      obscure: _obscurePassword,
                      suffixIcon: InkWell(
                        onTap: () {
                          setState(() {
                            _obscurePassword = !_obscurePassword;
                          });
                        },
                        child: Icon(
                          _obscurePassword ? Icons.visibility_off : Icons.visibility,
                          color: subtextColor,
                          size: 16,
                        ),
                      ),
                      textColor: textColor,
                      subtextColor: subtextColor,
                      borderColor: borderColor,
                    ),

                    if (_isSignUp) ...[
                      const SizedBox(height: 16),
                      _buildTextField(
                        controller: _confirmPasswordController,
                        hint: "Confirmer le mot de passe",
                        icon: Icons.lock_outline,
                        obscure: _obscurePassword,
                        textColor: textColor,
                        subtextColor: subtextColor,
                        borderColor: borderColor,
                      ),
                    ],

                    const SizedBox(height: 24),

                    // Submit Button
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : _handleAuth,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF4F46E5),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          elevation: 0,
                        ),
                        child: _isLoading
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                              )
                            : Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    widget.type == 'admin'
                                        ? 'Se connecter'
                                        : (_isSignUp ? 'Créer le compte' : 'Se connecter'),
                                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'Outfit'),
                                  ),
                                  const SizedBox(width: 8),
                                  const Icon(Icons.arrow_forward, size: 14),
                                ],
                              ),
                      ),
                    ),

                    // Toggle Parent Signin / Signup (no signup for admin)
                    if (widget.type != 'admin') ...[
                      const SizedBox(height: 24),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            _isSignUp ? "Déjà un compte ? " : "Pas encore de compte ? ",
                            style: TextStyle(color: subtextColor, fontSize: 11),
                          ),
                          InkWell(
                            onTap: () {
                              setState(() {
                                _isSignUp = !_isSignUp;
                                _errorMessage = null;
                              });
                            },
                            child: const Text(
                              "S'inscrire" == "" ? "" : "S'identifier / S'inscrire",
                              style: TextStyle(color: Color(0xFF4F46E5), fontSize: 11, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                    ],

                    const SizedBox(height: 24),
                    const Divider(color: Colors.white10),
                    const SizedBox(height: 12),

                    // Back to home
                    InkWell(
                      onTap: () => context.go('/'),
                      child: Text(
                        "Retour à l'accueil",
                        style: TextStyle(color: subtextColor, fontSize: 11, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool obscure = false,
    Widget? suffixIcon,
    TextInputType keyboardType = TextInputType.text,
    required Color textColor,
    required Color subtextColor,
    required Color borderColor,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: _isDark ? Colors.black.withOpacity(0.4) : const Color(0xFFF1F5F9),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Icon(icon, color: subtextColor, size: 16),
          const SizedBox(width: 12),
          Expanded(
            child: TextField(
              controller: controller,
              obscureText: obscure,
              keyboardType: keyboardType,
              style: TextStyle(color: textColor, fontSize: 12, fontFamily: 'Outfit'),
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: TextStyle(color: subtextColor, fontSize: 12, fontFamily: 'Outfit'),
                border: InputBorder.none,
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
          ),
          if (suffixIcon != null) suffixIcon,
        ],
      ),
    );
  }
}
