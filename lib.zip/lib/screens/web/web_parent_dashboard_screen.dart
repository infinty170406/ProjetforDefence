import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../core/services/api_service.dart';
import '../../core/services/storage_service.dart';

class WebParentDashboardScreen extends StatefulWidget {
  const WebParentDashboardScreen({super.key});

  @override
  State<WebParentDashboardScreen> createState() => _WebParentDashboardScreenState();
}

class _WebParentDashboardScreenState extends State<WebParentDashboardScreen> with TickerProviderStateMixin {
  String _activeTab = 'dashboard'; // 'dashboard', 'ai_orchestrator', 'stats', 'live_map'
  int _notificationsCount = 3;
  int _lucasLimit = 120;
  String _statsPeriod = 'day'; // 'day', 'week'
  String _selectedChild = 'emma';
  bool _isRefreshing = false;
  bool _isDark = true;

  late AnimationController _radarController;

  @override
  void initState() {
    super.initState();
    _radarController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();
  }

  @override
  void dispose() {
    _radarController.dispose();
    super.dispose();
  }

  void _triggerToast(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(color: Colors.white, fontFamily: 'Outfit', fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFF4F46E5),
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  void _handleReduceLimit() {
    setState(() {
      _lucasLimit = (math.max(30, (_lucasLimit * 0.75).round()));
    });
    _triggerToast("Limite quotidienne réduite à $_lucasLimit min pour Lucas ✓");
  }

  void _handleResetLimit() {
    setState(() {
      _lucasLimit = 120;
    });
    _triggerToast("Limite réinitialisée à 120 min pour Lucas");
  }

  void _handleRefresh() {
    setState(() {
      _isRefreshing = true;
    });
    _triggerToast("Actualisation des données en temps réel...");
    Future.delayed(const Duration(milliseconds: 1200), () {
      if (mounted) {
        setState(() {
          _isRefreshing = false;
        });
      }
    });
  }

  Future<void> _handleLogout() async {
    ApiService().clearToken();
    await FirebaseAuth.instance.signOut();
    await StorageService().clearAll();
    if (mounted) {
      context.go('/login/parent');
    }
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    final backgroundColor = _isDark ? const Color(0xFF020617) : const Color(0xFFF4F6FF);
    final cardColor = _isDark ? const Color(0xFF0B1329).withOpacity(0.8) : Colors.white.withOpacity(0.85);
    final textColor = _isDark ? Colors.white : const Color(0xFF1E293B);
    final subtextColor = _isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
    final borderColor = _isDark ? Colors.white.withOpacity(0.1) : const Color(0xFFE2E8F0)!;

    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isSmallScreen = screenWidth < 950;

    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: backgroundColor,
      drawer: isSmallScreen
          ? Drawer(
              child: _buildSidebar(textColor, subtextColor, borderColor, isDrawer: true),
            )
          : null,
      body: Stack(
        children: [
          // Ambient background glows
          Positioned(
            top: -100,
            right: -100,
            child: Container(
              width: 400,
              height: 400,
              decoration: BoxDecoration(
                color: const Color(0xFF4F46E5).withOpacity(_isDark ? 0.05 : 0.03),
                shape: BoxShape.circle,
              ),
            ),
          ),

          // Main Layout Row
          Row(
            children: [
              if (!isSmallScreen) _buildSidebar(textColor, subtextColor, borderColor),
              Expanded(
                child: Column(
                  children: [
                    _buildHeader(textColor, subtextColor, borderColor),
                    Expanded(
                      child: SingleChildScrollView(
                        padding: EdgeInsets.all(isSmallScreen ? 16 : 32),
                        child: _buildTabContent(cardColor, textColor, subtextColor, borderColor),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSidebar(Color textColor, Color subtextColor, Color borderColor, {bool isDrawer = false}) {
    return Container(
      width: 240,
      decoration: BoxDecoration(
        color: _isDark ? const Color(0xFF090B16).withOpacity(0.95) : Colors.white.withOpacity(0.95),
        border: isDrawer
            ? null
            : Border(
                right: BorderSide(color: borderColor),
              ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            children: [
              // Logo
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(color: borderColor),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF4F46E5), Color(0xFF14B8A6)],
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.shield, color: Colors.white, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "THE GUARDIAN",
                            style: TextStyle(
                              color: textColor,
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.2,
                              fontFamily: 'Outfit',
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            "Console Web Parent",
                            style: TextStyle(
                              color: subtextColor,
                              fontSize: 8,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Outfit',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // Navigation Menu
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _buildSidebarItem('dashboard', 'Vue Générale', Icons.dashboard, textColor, subtextColor, isDrawer: isDrawer),
                    _buildSidebarItem('ai_orchestrator', 'Orchestrateur IA', Icons.auto_awesome, textColor, subtextColor, badge: 'IA', isDrawer: isDrawer),
                    _buildSidebarItem('stats', 'Statistiques', Icons.bar_chart, textColor, subtextColor, isDrawer: isDrawer),
                    _buildSidebarItem('live_map', 'Carte en Direct', Icons.map, textColor, subtextColor, isDrawer: isDrawer),
                  ],
                ),
              ),
            ],
          ),

          // Logout & Theme Row
          Column(
            children: [
              // Theme Toggle item in sidebar
              ListTile(
                leading: Icon(
                  _isDark ? Icons.wb_sunny : Icons.nightlight_round,
                  color: _isDark ? Colors.yellow : const Color(0xFF4F46E5),
                  size: 16,
                ),
                title: Text(
                  _isDark ? "Mode Clair" : "Mode Sombre",
                  style: TextStyle(color: textColor, fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'Outfit'),
                ),
                onTap: () {
                  setState(() {
                    _isDark = !_isDark;
                  });
                },
              ),
              const Divider(color: Colors.white10),
              ListTile(
                leading: const Icon(Icons.logout, color: Colors.red, size: 16),
                title: const Text(
                  "Déconnexion",
                  style: TextStyle(color: Colors.red, fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'Outfit'),
                ),
                onTap: () {
                  if (isDrawer) {
                    Navigator.of(context).pop();
                  }
                  _handleLogout();
                },
              ),
              const SizedBox(height: 12),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSidebarItem(String id, String label, IconData icon, Color textColor, Color subtextColor, {String? badge, bool isDrawer = false}) {
    final isSelected = _activeTab == id;
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: InkWell(
        onTap: () {
          setState(() {
            _activeTab = id;
          });
          if (isDrawer) {
            Navigator.of(context).pop();
          }
        },
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            gradient: isSelected
                ? const LinearGradient(
                    colors: [Color(0xFF4F46E5), Color(0xFF3B32C4)],
                  )
                : null,
            color: isSelected ? null : Colors.transparent,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(
                    icon,
                    color: isSelected ? Colors.white : subtextColor,
                    size: 16,
                  ),
                  const SizedBox(width: 12),
                  Text(
                    label,
                    style: TextStyle(
                      color: isSelected ? Colors.white : textColor,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Outfit',
                    ),
                  ),
                ],
              ),
              if (badge != null)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: isSelected ? Colors.white.withOpacity(0.2) : const Color(0xFF4F46E5).withOpacity(0.2),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    badge,
                    style: TextStyle(
                      color: isSelected ? Colors.white : const Color(0xFF14B8A6),
                      fontSize: 8,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(Color textColor, Color subtextColor, Color borderColor) {
    String title = "Vue Générale";
    if (_activeTab == 'ai_orchestrator') title = "Orchestrateur IA Central";
    if (_activeTab == 'stats') title = "Statistiques d'utilisation";
    if (_activeTab == 'live_map') title = "Position temps réel & Zones";

    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isSmallScreen = screenWidth < 950;

    return Container(
      height: 70,
      decoration: BoxDecoration(
        color: _isDark ? const Color(0xFF090B16).withOpacity(0.7) : Colors.white.withOpacity(0.7),
        border: Border(bottom: BorderSide(color: borderColor)),
      ),
      padding: EdgeInsets.symmetric(horizontal: isSmallScreen ? 16 : 32),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              if (isSmallScreen) ...[
                IconButton(
                  icon: Icon(Icons.menu, color: textColor),
                  onPressed: () {
                    _scaffoldKey.currentState?.openDrawer();
                  },
                ),
                const SizedBox(width: 8),
              ],
              Container(
                width: 8,
                height: 8,
                decoration: const BoxDecoration(color: Color(0xFF4F46E5), shape: BoxShape.circle),
              ),
              const SizedBox(width: 10),
              Text(
                title.toUpperCase(),
                style: TextStyle(
                  color: textColor,
                  fontSize: isSmallScreen ? 10 : 12,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.5,
                  fontFamily: 'Outfit',
                ),
              ),
            ],
          ),
          Row(
            children: [
              InkWell(
                onTap: () {
                  setState(() {
                    _notificationsCount = 0;
                  });
                  _triggerToast("Toutes les notifications ont été lues.");
                },
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: borderColor),
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Icon(Icons.notifications_none, color: subtextColor, size: 16),
                      if (_notificationsCount > 0)
                        Positioned(
                          top: 6,
                          right: 6,
                          child: Container(
                            width: 14,
                            height: 14,
                            decoration: const BoxDecoration(
                              color: Colors.red,
                              shape: BoxShape.circle,
                            ),
                            child: Center(
                              child: Text(
                                "$_notificationsCount",
                                style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 12),
              InkWell(
                onTap: _handleRefresh,
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: borderColor),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.refresh,
                        color: _isRefreshing ? const Color(0xFF4F46E5) : subtextColor,
                        size: 14,
                      ),
                      if (!isSmallScreen) ...[
                        const SizedBox(width: 8),
                        Text(
                          "ACTUALISER",
                          style: TextStyle(color: subtextColor, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 1, fontFamily: 'Outfit'),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTabContent(Color cardColor, Color textColor, Color subtextColor, Color borderColor) {
    switch (_activeTab) {
      case 'dashboard':
        return _buildDashboardTab(cardColor, textColor, subtextColor, borderColor);
      case 'ai_orchestrator':
        return _buildAiOrchestratorTab(cardColor, textColor, subtextColor, borderColor);
      case 'stats':
        return _buildStatsTab(cardColor, textColor, subtextColor, borderColor);
      case 'live_map':
        return _buildLiveMapTab(cardColor, textColor, subtextColor, borderColor);
      default:
        return const SizedBox();
    }
  }

  Widget _buildDashboardTab(Color cardColor, Color textColor, Color subtextColor, Color borderColor) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isSmallScreen = screenWidth < 950;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Welcome banner
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: borderColor),
            gradient: LinearGradient(
              colors: [
                const Color(0xFF4F46E5).withOpacity(0.1),
                const Color(0xFF14B8A6).withOpacity(0.05),
              ],
            ),
          ),
          child: isSmallScreen
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: const Color(0xFF4F46E5).withOpacity(0.2),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.favorite, color: Color(0xFF4F46E5), size: 20),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Text(
                            "Supervision Famille Active",
                            style: TextStyle(color: textColor, fontSize: 14, fontWeight: FontWeight.w900, fontFamily: 'Outfit'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      "Vos enfants sont connectés. Les protocoles de protection locale sont appliqués.",
                      style: TextStyle(color: subtextColor, fontSize: 11, fontFamily: 'Outfit'),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "DERNIER HEARTBEAT",
                          style: TextStyle(color: subtextColor, fontSize: 8, fontWeight: FontWeight.bold, fontFamily: 'Outfit'),
                        ),
                        const Text(
                          "Synchronisé",
                          style: TextStyle(color: Color(0xFF10B981), fontSize: 12, fontWeight: FontWeight.bold, fontFamily: 'Outfit'),
                        ),
                      ],
                    ),
                  ],
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: const Color(0xFF4F46E5).withOpacity(0.2),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.favorite, color: Color(0xFF4F46E5), size: 20),
                        ),
                        const SizedBox(width: 16),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Supervision Famille Active",
                              style: TextStyle(color: textColor, fontSize: 14, fontWeight: FontWeight.w900, fontFamily: 'Outfit'),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Vos enfants sont connectés. Les protocoles de protection locale sont appliqués.",
                              style: TextStyle(color: subtextColor, fontSize: 11, fontFamily: 'Outfit'),
                            ),
                          ],
                        ),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          "DERNIER HEARTBEAT",
                          style: TextStyle(color: subtextColor, fontSize: 8, fontWeight: FontWeight.bold, fontFamily: 'Outfit'),
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          "Synchronisé",
                          style: TextStyle(color: Color(0xFF10B981), fontSize: 12, fontWeight: FontWeight.bold, fontFamily: 'Outfit'),
                        ),
                      ],
                    ),
                  ],
                ),
        ),
        const SizedBox(height: 32),

        // Children cards row
        isSmallScreen
            ? Column(
                children: [
                  _buildChildDashboardCard('Emma', '12 ans', 45, 120, 'COLLÈGE', const Color(0xFF14B8A6), 'E', cardColor, textColor, subtextColor, borderColor),
                  const SizedBox(height: 16),
                  _buildChildDashboardCard('Lucas', '15 ans', _lucasLimit, 120, 'MAISON', const Color(0xFFEF4444), 'L', cardColor, textColor, subtextColor, borderColor, isRisk: true),
                ],
              )
            : Row(
                children: [
                  Expanded(child: _buildChildDashboardCard('Emma', '12 ans', 45, 120, 'COLLÈGE', const Color(0xFF14B8A6), 'E', cardColor, textColor, subtextColor, borderColor)),
                  const SizedBox(width: 24),
                  Expanded(child: _buildChildDashboardCard('Lucas', '15 ans', _lucasLimit, 120, 'MAISON', const Color(0xFFEF4444), 'L', cardColor, textColor, subtextColor, borderColor, isRisk: true)),
                ],
              ),
        const SizedBox(height: 32),

        // AI quick access banner
        InkWell(
          onTap: () {
            setState(() {
              _activeTab = 'ai_orchestrator';
            });
          },
          borderRadius: BorderRadius.circular(20),
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF4F46E5).withOpacity(0.3)),
              gradient: LinearGradient(
                colors: [
                  const Color(0xFF4F46E5).withOpacity(0.2),
                  const Color(0xFF14B8A6).withOpacity(0.1),
                ],
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: const Color(0xFF4F46E5).withOpacity(0.3),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.auto_awesome, color: Color(0xFF14B8A6), size: 22),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Wrap(
                              crossAxisAlignment: WrapCrossAlignment.center,
                              spacing: 10,
                              runSpacing: 4,
                              children: [
                                Text(
                                  "Orchestrateur IA Actif",
                                  style: TextStyle(color: textColor, fontSize: 14, fontWeight: FontWeight.w900, fontFamily: 'Outfit'),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF10B981).withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(6),
                                    border: Border.all(color: const Color(0xFF10B981).withOpacity(0.2)),
                                  ),
                                  child: const Text(
                                    "2 ALERTES RÉSOLUES",
                                    style: TextStyle(color: Color(0xFF10B981), fontSize: 8, fontWeight: FontWeight.bold, fontFamily: 'Outfit'),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Text(
                              "Analyse comportementale en cours • 2 recommandations système prêtes pour action.",
                              style: TextStyle(color: subtextColor, fontSize: 11, fontFamily: 'Outfit'),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(Icons.chevron_right, color: const Color(0xFF4F46E5), size: 24),
              ],
            ),
          ),
        ),
        const SizedBox(height: 32),

        // Live Log
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: borderColor),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.history, color: Color(0xFF4F46E5), size: 16),
                  const SizedBox(width: 10),
                  Text(
                    "JOURNAL SYSTÈME EN DIRECT",
                    style: TextStyle(color: subtextColor, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1, fontFamily: 'Outfit'),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              _buildLogItem('Il y a 3 min', 'Lucas', 'Accès Intercepté : poker-online.com', 'Filtre Réseau DNS : Catégorie Jeux d\'argent interdite', const Color(0xFFEF4444), textColor, subtextColor),
              _buildLogItem('Il y a 12 min', 'Emma', 'Entrée Geofence : Zone Collège', 'Coordonnées GPS conformes au geofencing d\'école', const Color(0xFF10B981), textColor, subtextColor),
              _buildLogItem('Il y a 25 min', 'Lucas', 'Verrouillage Système : TikTok', 'Quota de temps d\'écran atteint pour cette application', const Color(0xFFFBBF24), textColor, subtextColor),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildChildDashboardCard(
    String name,
    String age,
    int used,
    int max,
    String zone,
    Color statusColor,
    String avatarText,
    Color cardColor,
    Color textColor,
    Color subtextColor,
    Color borderColor, {
    bool isRisk = false,
  }) {
    final double percent = math.min(1.0, used / max);
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: statusColor.withOpacity(0.15),
                      shape: BoxShape.circle,
                      border: Border.all(color: statusColor.withOpacity(0.3)),
                    ),
                    child: Center(
                      child: Text(
                        avatarText,
                        style: TextStyle(color: statusColor, fontWeight: FontWeight.w900, fontSize: 14, fontFamily: 'Outfit'),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(name, style: TextStyle(color: textColor, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'Outfit')),
                          const SizedBox(width: 6),
                          Container(
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(color: statusColor, shape: BoxShape.circle),
                          ),
                        ],
                      ),
                      Text("$age • App Active", style: TextStyle(color: subtextColor, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Outfit')),
                    ],
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: statusColor.withOpacity(0.2)),
                ),
                child: Text(
                  isRisk ? "RISQUE ÉLEVÉ" : "SÉCURISÉ",
                  style: TextStyle(color: statusColor, fontSize: 9, fontWeight: FontWeight.bold, fontFamily: 'Outfit'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Temps utilisé : $used min", style: TextStyle(color: subtextColor, fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'Outfit')),
              Text(
                isRisk && used >= max ? "Quota Épuisé" : "${max - used} min restants",
                style: TextStyle(color: isRisk && used >= max ? const Color(0xFFEF4444) : const Color(0xFF10B981), fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'Outfit'),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            height: 8,
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.black12,
              borderRadius: BorderRadius.circular(4),
            ),
            child: FractionallySizedBox(
              alignment: Alignment.centerLeft,
              widthFactor: percent,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [statusColor, statusColor.withOpacity(0.7)],
                  ),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.only(top: 16),
            decoration: BoxDecoration(
              border: Border(top: BorderSide(color: borderColor)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.location_on, color: Color(0xFF10B981), size: 12),
                    const SizedBox(width: 6),
                    Text("ZONE : $zone", style: TextStyle(color: subtextColor, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Outfit')),
                  ],
                ),
                InkWell(
                  onTap: () {
                    setState(() {
                      _selectedChild = name.toLowerCase();
                      _activeTab = 'stats';
                    });
                  },
                  child: const Text("Stats →", style: TextStyle(color: Color(0xFF4F46E5), fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'Outfit')),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLogItem(String time, String user, String event, String detail, Color indicatorColor, Color textColor, Color subtextColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: indicatorColor,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: "$user : ",
                          style: TextStyle(color: textColor, fontSize: 11, fontWeight: FontWeight.w900, fontFamily: 'Outfit'),
                        ),
                        TextSpan(
                          text: event,
                          style: TextStyle(color: textColor.withOpacity(0.8), fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'Outfit'),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(detail, style: TextStyle(color: subtextColor, fontSize: 10, fontFamily: 'Outfit')),
                ],
              ),
            ],
          ),
          Text(time, style: TextStyle(color: subtextColor, fontSize: 10, fontFamily: 'monospace')),
        ],
      ),
    );
  }

  Widget _buildAiOrchestratorTab(Color cardColor, Color textColor, Color subtextColor, Color borderColor) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isSmallScreen = screenWidth < 950;

    return Column(
      children: [
        // Stats grid
        isSmallScreen
            ? Column(
                children: [
                  _buildAiStatCard("4", "Requêtes Bloquées", Icons.shield, const Color(0xFFEF4444), borderColor),
                  const SizedBox(height: 16),
                  _buildAiStatCard("1", "Limite Dépassée", Icons.warning, const Color(0xFFFBBF24), borderColor),
                  const SizedBox(height: 16),
                  _buildAiStatCard("2", "Rapports au Vert", Icons.check_circle, const Color(0xFF10B981), borderColor),
                ],
              )
            : Row(
                children: [
                  Expanded(child: _buildAiStatCard("4", "Requêtes Bloquées", Icons.shield, const Color(0xFFEF4444), borderColor)),
                  const SizedBox(width: 16),
                  Expanded(child: _buildAiStatCard("1", "Limite Dépassée", Icons.warning, const Color(0xFFFBBF24), borderColor)),
                  const SizedBox(width: 16),
                  Expanded(child: _buildAiStatCard("2", "Rapports au Vert", Icons.check_circle, const Color(0xFF10B981), borderColor)),
                ],
              ),
        const SizedBox(height: 32),

        // Lucas AI Advice Card
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: const Color(0xFFEF4444).withOpacity(0.05),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.25)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Row(
                      children: [
                        Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            color: const Color(0xFFEF4444).withOpacity(0.15),
                            shape: BoxShape.circle,
                          ),
                          child: const Center(
                            child: Text("L", style: TextStyle(color: Color(0xFFEF4444), fontWeight: FontWeight.w900, fontSize: 13, fontFamily: 'Outfit')),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Lucas (15 ans)", style: TextStyle(color: textColor, fontSize: 13, fontWeight: FontWeight.bold, fontFamily: 'Outfit')),
                              Text("4 alertes de filtrage DNS détectées", style: TextStyle(color: subtextColor, fontSize: 10, fontFamily: 'Outfit'), overflow: TextOverflow.ellipsis),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEF4444).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.2)),
                    ),
                    child: const Text("RISQUE ÉLEVÉ", style: TextStyle(color: Color(0xFFEF4444), fontSize: 9, fontWeight: FontWeight.bold, fontFamily: 'Outfit')),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Temps d'écran utilisé : 120 min", style: TextStyle(color: subtextColor, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Outfit')),
                  Text("Quota : 120 min", style: TextStyle(color: subtextColor, fontSize: 10, fontFamily: 'Outfit')),
                ],
              ),
              const SizedBox(height: 8),
              Container(
                height: 6,
                width: double.infinity,
                decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(3)),
                child: FractionallySizedBox(
                  alignment: Alignment.centerLeft,
                  widthFactor: 1.0,
                  child: Container(color: const Color(0xFFEF4444)),
                ),
              ),
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: borderColor),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.auto_awesome, color: Color(0xFF14B8A6), size: 14),
                        SizedBox(width: 8),
                        Text("Avis de l'Orchestrateur IA", style: TextStyle(color: Color(0xFF4F46E5), fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 0.5, fontFamily: 'Outfit')),
                      ],
                    ),
                    SizedBox(height: 10),
                    Text(
                      "Diagnostic : Tentatives d'accès répétées à poker-online.com (bloquées par DNS). Nous conseillons d'engager une discussion bienveillante avec Lucas sur la prévention des risques financiers et des jeux d'argent à son âge.",
                      style: TextStyle(color: Colors.grey, fontSize: 12, height: 1.5, fontFamily: 'Outfit'),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              isSmallScreen
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        OutlinedButton(
                          onPressed: () => _triggerToast("Historique DNS exporté."),
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: borderColor),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            padding: const EdgeInsets.symmetric(vertical: 18),
                          ),
                          child: Text("JOURNAUX DNS", style: TextStyle(color: textColor, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Outfit')),
                        ),
                        const SizedBox(height: 12),
                        OutlinedButton(
                          onPressed: () {
                            setState(() {
                              _selectedChild = 'lucas';
                              _activeTab = 'stats';
                            });
                          },
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: Color(0xFF4F46E5)),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            padding: const EdgeInsets.symmetric(vertical: 18),
                          ),
                          child: const Text("RÈGLES APPS", style: TextStyle(color: Color(0xFF4F46E5), fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Outfit')),
                        ),
                        const SizedBox(height: 12),
                        ElevatedButton.icon(
                          onPressed: _lucasLimit > 60 ? _handleReduceLimit : _handleResetLimit,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFEF4444),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            padding: const EdgeInsets.symmetric(vertical: 18),
                          ),
                          icon: const Icon(Icons.timer, color: Colors.white, size: 14),
                          label: Text(
                            _lucasLimit > 60 ? "RÉDUIRE 25%" : "RÉTABLIR",
                            style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Outfit'),
                          ),
                        ),
                      ],
                    )
                  : Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => _triggerToast("Historique DNS exporté."),
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(color: borderColor),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              padding: const EdgeInsets.symmetric(vertical: 18),
                            ),
                            child: Text("JOURNAUX DNS", style: TextStyle(color: textColor, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Outfit')),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () {
                              setState(() {
                                _selectedChild = 'lucas';
                                _activeTab = 'stats';
                              });
                            },
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: Color(0xFF4F46E5)),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              padding: const EdgeInsets.symmetric(vertical: 18),
                            ),
                            child: const Text("RÈGLES APPS", style: TextStyle(color: Color(0xFF4F46E5), fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Outfit')),
                          ),
                        ),
                        const SizedBox(width: 12),
                        ElevatedButton.icon(
                          onPressed: _lucasLimit > 60 ? _handleReduceLimit : _handleResetLimit,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFEF4444),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
                          ),
                          icon: const Icon(Icons.timer, color: Colors.white, size: 14),
                          label: Text(
                            _lucasLimit > 60 ? "RÉDUIRE 25%" : "RÉTABLIR",
                            style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Outfit'),
                          ),
                        ),
                      ],
                    ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildAiStatCard(String val, String label, IconData icon, Color color, Color borderColor) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.15)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 12),
          Text(val, style: TextStyle(color: color, fontSize: 28, fontWeight: FontWeight.w900, fontFamily: 'monospace')),
          const SizedBox(height: 4),
          Text(label.toUpperCase(), style: const TextStyle(color: Colors.grey, fontSize: 9, fontWeight: FontWeight.bold, fontFamily: 'Outfit')),
        ],
      ),
    );
  }

  Widget _buildStatsTab(Color cardColor, Color textColor, Color subtextColor, Color borderColor) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isSmallScreen = screenWidth < 950;

    return Column(
      children: [
        // Subheader filter
        isSmallScreen
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      _buildTabButton(_selectedChild == 'emma', 'Emma', () {
                        setState(() {
                          _selectedChild = 'emma';
                        });
                      }, textColor, subtextColor),
                      const SizedBox(width: 12),
                      _buildTabButton(_selectedChild == 'lucas', 'Lucas', () {
                        setState(() {
                          _selectedChild = 'lucas';
                        });
                      }, textColor, subtextColor),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: cardColor,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: borderColor),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                          child: _buildPeriodButton(_statsPeriod == 'day', 'Jour', () {
                            setState(() {
                              _statsPeriod = 'day';
                            });
                          }, textColor, subtextColor),
                        ),
                        Expanded(
                          child: _buildPeriodButton(_statsPeriod == 'week', 'Semaine', () {
                            setState(() {
                              _statsPeriod = 'week';
                            });
                          }, textColor, subtextColor),
                        ),
                      ],
                    ),
                  ),
                ],
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      _buildTabButton(_selectedChild == 'emma', 'Emma', () {
                        setState(() {
                          _selectedChild = 'emma';
                        });
                      }, textColor, subtextColor),
                      const SizedBox(width: 12),
                      _buildTabButton(_selectedChild == 'lucas', 'Lucas', () {
                        setState(() {
                          _selectedChild = 'lucas';
                        });
                      }, textColor, subtextColor),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: cardColor,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: borderColor),
                    ),
                    child: Row(
                      children: [
                        _buildPeriodButton(_statsPeriod == 'day', 'Jour', () {
                          setState(() {
                            _statsPeriod = 'day';
                          });
                        }, textColor, subtextColor),
                        _buildPeriodButton(_statsPeriod == 'week', 'Semaine', () {
                          setState(() {
                            _statsPeriod = 'week';
                          });
                        }, textColor, subtextColor),
                      ],
                    ),
                  ),
                ],
              ),
        const SizedBox(height: 32),

        isSmallScreen
            ? Column(
                children: [
                  // Chart Area
                  Container(
                    height: 300,
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: cardColor,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: borderColor),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                _statsPeriod == 'day' ? 'RÉPARTITION QUOTIDIENNE' : 'USAGE HEBDOMADAIRE (MINUTES)',
                                style: TextStyle(color: subtextColor, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1, fontFamily: 'Outfit'),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.05),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                _selectedChild.toUpperCase(),
                                style: TextStyle(color: textColor, fontSize: 9, fontWeight: FontWeight.bold, fontFamily: 'Outfit'),
                              ),
                            ),
                          ],
                        ),
                        const Expanded(
                          child: Center(
                            child: Text(
                              "[ Visualisation Graphique Active ]",
                              style: TextStyle(color: Colors.grey, fontSize: 12, fontStyle: FontStyle.italic, fontFamily: 'Outfit'),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  // Top websites
                  Container(
                    height: 300,
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: cardColor,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: borderColor),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "TOP SITES VISITES",
                          style: TextStyle(color: subtextColor, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1, fontFamily: 'Outfit'),
                        ),
                        const SizedBox(height: 20),
                        _buildTopWebsitesList(textColor, subtextColor),
                      ],
                    ),
                  ),
                ],
              )
            : Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Chart Area
                  Expanded(
                    flex: 3,
                    child: Container(
                      height: 300,
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: cardColor,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: borderColor),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                _statsPeriod == 'day' ? 'RÉPARTITION QUOTIDIENNE' : 'USAGE HEBDOMADAIRE (MINUTES)',
                                style: TextStyle(color: subtextColor, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1, fontFamily: 'Outfit'),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.05),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Text(
                                  _selectedChild.toUpperCase(),
                                  style: TextStyle(color: textColor, fontSize: 9, fontWeight: FontWeight.bold, fontFamily: 'Outfit'),
                                ),
                              ),
                            ],
                          ),
                          const Expanded(
                            child: Center(
                              child: Text(
                                "[ Visualisation Graphique Active ]",
                                style: TextStyle(color: Colors.grey, fontSize: 12, fontStyle: FontStyle.italic, fontFamily: 'Outfit'),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 24),

                  // Top websites
                  Expanded(
                    flex: 2,
                    child: Container(
                      height: 300,
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: cardColor,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: borderColor),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "TOP SITES VISITES",
                            style: TextStyle(color: subtextColor, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1, fontFamily: 'Outfit'),
                          ),
                          const SizedBox(height: 20),
                          _buildTopWebsitesList(textColor, subtextColor),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
      ],
    );
  }

  Widget _buildTabButton(bool active, String label, VoidCallback onTap, Color textColor, Color subtextColor) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: BoxDecoration(
          color: active ? const Color(0xFF4F46E5) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: active ? Colors.white : subtextColor,
            fontSize: 12,
            fontWeight: FontWeight.bold,
            fontFamily: 'Outfit',
          ),
        ),
      ),
    );
  }

  Widget _buildPeriodButton(bool active, String label, VoidCallback onTap, Color textColor, Color subtextColor) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: active ? const Color(0xFF1E293B) : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: active ? Colors.white : subtextColor,
            fontSize: 10,
            fontWeight: FontWeight.bold,
            fontFamily: 'Outfit',
          ),
        ),
      ),
    );
  }

  Widget _buildTopWebsitesList(Color textColor, Color subtextColor) {
    final sites = _selectedChild == 'emma'
        ? [
            {'domain': 'duolingo.com', 'visits': '12 visites', 'title': 'Duolingo'},
            {'domain': 'wikipedia.org', 'visits': '6 visites', 'title': 'Wikipédia'},
            {'domain': 'quizlet.com', 'visits': '4 visites', 'title': 'Quizlet'},
          ]
        : [
            {'domain': 'minecraft.net', 'visits': '24 visites', 'title': 'Minecraft'},
            {'domain': 'roblox.com', 'visits': '18 visites', 'title': 'Roblox'},
            {'domain': 'discord.gg', 'visits': '10 visites', 'title': 'Discord'},
          ];

    return Column(
      children: sites
          .map((site) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(site['title']!, style: TextStyle(color: textColor, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: 'Outfit')),
                        Text(site['domain']!, style: TextStyle(color: subtextColor, fontSize: 10, fontFamily: 'Outfit')),
                      ],
                    ),
                    Text(site['visits']!, style: TextStyle(color: subtextColor, fontSize: 10, fontFamily: 'Outfit')),
                  ],
                ),
              ))
          .toList(),
    );
  }

  Widget _buildLiveMapTab(Color cardColor, Color textColor, Color subtextColor, Color borderColor) {
    return Column(
      children: [
        Container(
          height: 420,
          decoration: BoxDecoration(
            color: _isDark ? const Color(0xFF090B16) : Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: borderColor),
          ),
          clipBehavior: Clip.antiAlias,
          child: Stack(
            children: [
              // Radar sweep animation
              Positioned.fill(
                child: AnimatedBuilder(
                  animation: _radarController,
                  builder: (context, child) {
                    return CustomPaint(
                      painter: RadarPainter(_radarController.value),
                    );
                  },
                ),
              ),

              // Safe zone highlights
              Positioned(
                left: 200,
                top: 100,
                child: _buildRadarPin('Emma', const Color(0xFF14B8A6)),
              ),
              Positioned(
                right: 250,
                bottom: 120,
                child: _buildRadarPin('Lucas', const Color(0xFFEF4444)),
              ),

              // Title block on map
              Positioned(
                top: 24,
                left: 24,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.white.withOpacity(0.1)),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.radar, color: Color(0xFF14B8A6), size: 14),
                      SizedBox(width: 8),
                      Text("Balise GPS Active", style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Outfit')),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildRadarPin(String name, Color color) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: color.withOpacity(0.5)),
          ),
          child: Text(
            name,
            style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Outfit'),
          ),
        ),
        const SizedBox(height: 6),
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.5),
                blurRadius: 10,
                spreadRadius: 3,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class RadarPainter extends CustomPainter {
  final double progress;
  RadarPainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = math.min(size.width, size.height) / 2;

    final paint = Paint()
      ..color = const Color(0xFF14B8A6).withOpacity(0.02)
      ..style = PaintingStyle.fill;
    
    // Draw concentric circles
    final circlePaint = Paint()
      ..color = const Color(0xFF14B8A6).withOpacity(0.08)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;

    canvas.drawCircle(center, radius, paint);
    canvas.drawCircle(center, radius, circlePaint);
    canvas.drawCircle(center, radius * 0.7, circlePaint);
    canvas.drawCircle(center, radius * 0.4, circlePaint);

    // Crosslines
    canvas.drawLine(Offset(center.dx - radius, center.dy), Offset(center.dx + radius, center.dy), circlePaint);
    canvas.drawLine(Offset(center.dx, center.dy - radius), Offset(center.dx, center.dy + radius), circlePaint);

    // Sweep arc
    final sweepPaint = Paint()
      ..shader = SweepGradient(
        colors: [
          const Color(0xFF14B8A6).withOpacity(0.0),
          const Color(0xFF14B8A6).withOpacity(0.3),
        ],
        stops: const [0.0, 1.0],
        transform: GradientRotation(progress * 2 * math.pi),
      ).createShader(Rect.fromCircle(center: center, radius: radius));

    canvas.drawCircle(center, radius, sweepPaint);
  }

  @override
  bool shouldRepaint(RadarPainter oldDelegate) {
    return oldDelegate.progress != progress;
  }
}
