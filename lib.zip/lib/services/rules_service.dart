import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Geofence
///
/// Représente une zone de sécurité (Maison, École, etc.).
class Geofence {
  final String id;
  final String name;
  final double latitude;
  final double longitude;
  final double radius; // en mètres

  const Geofence({
    required this.id,
    required this.name,
    required this.latitude,
    required this.longitude,
    required this.radius,
  });

  factory Geofence.fromFirestore(Map<String, dynamic> data) {
    return Geofence(
      id:        data['id']        as String? ?? '',
      name:      data['name']      as String? ?? 'Zone Sans Nom',
      latitude:  (data['latitude']  as num?)?.toDouble() ?? 0.0,
      longitude: (data['longitude'] as num?)?.toDouble() ?? 0.0,
      radius:    (data['radius']    as num?)?.toDouble() ?? 100.0,
    );
  }

  @override
  String toString() => 'Geofence($name, r=$radius)';
}

/// ActiveRules
///
/// Représente l'état courant des règles configurées par le parent.
/// Tous les champs sont optionnels — une règle absente = non configurée = pas de restriction.
class ActiveRules {
  /// Apps individuellement bloquées (packages Android ex: "com.tiktok")
  final Set<String> blockedApps;

  /// Limite journalière de temps d'écran en minutes (0 = pas de limite)
  final int dailyLimitMinutes;

  /// Plage horaire autorisée — heure de début "HH:MM" (null = pas de restriction)
  final String? allowedTimeStart;

  /// Plage horaire autorisée — heure de fin "HH:MM" (null = pas de restriction)
  final String? allowedTimeEnd;

  /// Bloquer tous les packages de la catégorie réseaux sociaux
  final bool blockSocialMedia;

  /// Bloquer tous les packages de la catégorie jeux
  final bool blockGaming;

  /// [NEW] Liste des domaines web bloqués (ex: "facebook.com")
  final Set<String> blockedWebsites;

  /// [NEW] Activer le filtrage de contenu adulte (violence, contenu explicite)
  final bool blockAdultContent;

  /// [NEW] Bloquer les contenus violents
  final bool blockViolence;

  /// [NEW] Bloquer les sites de jeux d'argent/paris
  final bool blockGambling;

  /// [NEW] Mots-clés personnalisés (frappe clavier / écran)
  final Set<String> customKeywords;

  /// [NEW] Zones de sécurité GPS
  final List<Geofence> geofences;

  /// [NEW] Limites de temps par application (PackageName -> Minutes)
  final Map<String, int> appTimeLimits;

  const ActiveRules({
    this.blockedApps       = const {},
    this.dailyLimitMinutes = 0,
    this.allowedTimeStart,
    this.allowedTimeEnd,
    this.blockSocialMedia  = false,
    this.blockGaming       = false,
    this.blockedWebsites   = const {},
    this.blockAdultContent = false,
    this.blockViolence     = false,
    this.blockGambling     = false,
    this.customKeywords    = const {},
    this.geofences         = const [],
    this.appTimeLimits     = const {},
  });

  /// Règles vides = aucune restriction active
  static const empty = ActiveRules();

  factory ActiveRules.fromFirestore(Map<String, dynamic> data) {
    final apps = data['blockedApps'] as List<dynamic>? ?? [];
    final webs = data['blockedWebsites'] as List<dynamic>? ?? [];
    final keys = data['customKeywords'] as List<dynamic>? ?? [];
    final geos = data['geofences']   as List<dynamic>? ?? [];
    final limits = data['appTimeLimits'] as Map<String, dynamic>? ?? {};
    
    return ActiveRules(
      blockedApps:       apps.map((e) => e.toString()).toSet(),
      dailyLimitMinutes: (data['dailyLimitMinutes'] as num?)?.toInt() ?? 0,
      allowedTimeStart:  data['allowedTimeStart']  as String?,
      allowedTimeEnd:    data['allowedTimeEnd']    as String?,
      blockSocialMedia:  data['blockSocialMedia']  as bool? ?? false,
      blockGaming:       data['blockGaming']       as bool? ?? false,
      blockedWebsites:   webs.map((e) => e.toString()).toSet(),
      blockAdultContent: data['blockAdultContent'] as bool? ?? false,
      blockViolence:     data['blockViolence']     as bool? ?? false,
      blockGambling:     data['blockGambling']     as bool? ?? false,
      customKeywords:    keys.map((e) => e.toString()).toSet(),
      geofences:         geos.map((e) => Geofence.fromFirestore(e)).toList(),
      appTimeLimits:     limits.map((k, v) => MapEntry(k, (v as num).toInt())),
    );
  }

  /// Retourne l'ensemble complet des packages effectivement bloqués
  /// (règles individuelles + catégories).
  Set<String> effectiveBlockedPackages({
    required Set<String> socialMediaPackages,
    required Set<String> gamingPackages,
  }) {
    final result = <String>{...blockedApps};
    if (blockSocialMedia) result.addAll(socialMediaPackages);
    if (blockGaming)      result.addAll(gamingPackages);
    return result;
  }

  bool get hasAnyRule =>
      blockedApps.isNotEmpty ||
      dailyLimitMinutes > 0  ||
      allowedTimeStart != null ||
      blockSocialMedia ||
      blockGaming ||
      blockedWebsites.isNotEmpty ||
      blockAdultContent ||
      blockViolence ||
      blockGambling ||
      customKeywords.isNotEmpty ||
      geofences.isNotEmpty;

  @override
  String toString() =>
      'ActiveRules(apps=${blockedApps.length}, limit=$dailyLimitMinutes, '
      'hours=$allowedTimeStart-$allowedTimeEnd, '
      'social=$blockSocialMedia, gaming=$blockGaming, '
      'websites=${blockedWebsites.length}, adult=$blockAdultContent, '
      'keywords=${customKeywords.length}, '
      'geos=${geofences.length})';
}

/// RulesService
///
/// Écoute en **temps réel** le document Firestore `{childPath}/rules/active`.
/// Chaque modification faite par le parent est reçue instantanément et
/// propagée à tous les listeners (EnforcementService, AppState, UI).
///
/// Pattern : stream + callback pour permettre une utilisation depuis
/// l'isolate background du foreground service.
class RulesService {
  static final RulesService _instance = RulesService._internal();
  factory RulesService() => _instance;
  RulesService._internal();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  StreamSubscription<DocumentSnapshot>? _subscription;
  ActiveRules _current = ActiveRules.empty;

  // Callbacks enregistrés par les consommateurs
  final List<void Function(ActiveRules)> _listeners = [];

  ActiveRules get current => _current;

  /// Démarre l'écoute temps réel du document rules/active.
  /// Idempotent — appels multiples sont ignorés.
  Future<void> start() async {
    if (_subscription != null) return;

    final prefs = await SharedPreferences.getInstance();
    final childPath = prefs.getString('child_path');
    if (childPath == null) {
      debugPrint('RulesService: child_path not set — cannot start.');
      return;
    }

    final docPath = '$childPath/rules/active';
    debugPrint('RulesService: [DIAGNOSTIC] Listening to path: $docPath');
    debugPrint('RulesService: [DIAGNOSTIC] Current Firebase Project: ${_firestore.app.options.projectId}');

    _subscription = _firestore.doc(docPath).snapshots().listen(
      (snap) {
        if (!snap.exists) {
          debugPrint('RulesService: [DIAGNOSTIC] Document DOES NOT EXIST at $docPath');
          _current = ActiveRules.empty;
        } else {
          debugPrint('RulesService: [DIAGNOSTIC] Document updated at $docPath');
          _current = ActiveRules.fromFirestore(
              snap.data() as Map<String, dynamic>);
        }
        debugPrint('RulesService: Rules updated → $_current');
        for (final cb in List.of(_listeners)) {
          cb(_current);
        }
      },
      onError: (e) => debugPrint('RulesService: Firestore error: $e'),
    );
  }

  /// Arrête l'écoute et réinitialise les règles.
  Future<void> stop() async {
    await _subscription?.cancel();
    _subscription = null;
    _current = ActiveRules.empty;
    debugPrint('RulesService: Stopped.');
  }

  /// Enregistre un callback appelé à chaque mise à jour des règles.
  void addListener(void Function(ActiveRules) callback) {
    _listeners.add(callback);
  }

  void removeListener(void Function(ActiveRules) callback) {
    _listeners.remove(callback);
  }
}
