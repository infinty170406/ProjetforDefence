import 'package:flutter/material.dart';
import 'dart:convert';
import '../theme/app_theme.dart';

class AppListItem extends StatelessWidget {
  final String label;
  final String packageName;
  final int usageMinutes;
  final double progress; // 0.0 to 1.0
  final String category;
  final String? trailingText;
  final Widget? trailing;
  final bool showProgress;
  final String? iconUrl;
  final String? iconBase64;
  final IconData? fallbackIcon;

  const AppListItem({
    super.key,
    required this.label,
    required this.packageName,
    this.usageMinutes = 0,
    this.progress = 0.0,
    this.category = 'other',
    this.trailingText,
    this.trailing,
    this.showProgress = true,
    this.iconUrl,
    this.iconBase64,
    this.fallbackIcon,
  });

  @override
  Widget build(BuildContext context) {
    final color = _categoryColor(category);
    final icon = fallbackIcon ?? _categoryIcon(category);
    final String timeStr = trailingText ?? _formatMinutes(usageMinutes);
    final String? cleanBase64 = _getCleanBase64(iconBase64);

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              // Premium Icon Container
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: color.withValues(alpha: 0.1), width: 1),
                ),
                child: Center(
                  child: cleanBase64 != null
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.memory(
                            base64Decode(cleanBase64),
                            width: 32,
                            height: 32,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Icon(icon, size: 24, color: color),
                          ),
                        )
                      : iconUrl != null && iconUrl!.isNotEmpty
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Image.network(
                                iconUrl!,
                                width: 32,
                                height: 32,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Icon(icon, size: 24, color: color),
                              ),
                            )
                          : Icon(icon, size: 24, color: color),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      label,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 15,
                        letterSpacing: 0.3,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    // Removed packageName display as requested
                  ],
                ),
              ),
              const SizedBox(width: 8),
              if (trailing != null)
                trailing!
              else
                Text(
                  timeStr,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
            ],
          ),
          if (showProgress) ...[
            const SizedBox(height: 10),
            Container(
              height: 4,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(2),
              ),
              child: FractionallySizedBox(
                alignment: Alignment.centerLeft,
                widthFactor: progress.clamp(0.0, 1.0),
                child: Container(
                  decoration: BoxDecoration(
                    color: color,
                    borderRadius: BorderRadius.circular(2),
                    boxShadow: [
                      BoxShadow(
                        color: color.withValues(alpha: 0.3),
                        blurRadius: 4,
                        offset: const Offset(0, 0),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Color _categoryColor(String cat) {
    switch (cat.toLowerCase().trim()) {
      case 'social_media':
      case 'social':
        return Colors.pinkAccent;
      case 'gaming':
      case 'game':
      case 'jeux':
        return Colors.purpleAccent;
      case 'education':
      case 'school':
      case 'educational':
        return Colors.greenAccent;
      case 'browser':
      case 'web':
      case 'internet':
        return Colors.blueAccent;
      case 'messaging':
      case 'message':
      case 'chat':
      case 'communication':
        return Colors.tealAccent;
      default:
        return AppColors.primary;
    }
  }

  IconData _categoryIcon(String cat) {
    switch (cat.toLowerCase().trim()) {
      case 'social_media':
      case 'social':
        return Icons.thumb_up;
      case 'gaming':
      case 'game':
      case 'jeux':
        return Icons.videogame_asset;
      case 'education':
      case 'school':
      case 'educational':
        return Icons.school;
      case 'browser':
      case 'web':
      case 'internet':
        return Icons.language;
      case 'messaging':
      case 'message':
      case 'chat':
      case 'communication':
        return Icons.chat;
      default:
        return Icons.apps;
    }
  }

  String _formatMinutes(int mins) {
    if (mins == 0) return '0m';
    if (mins < 60) return '${mins}m';
    final h = mins ~/ 60;
    final m = mins % 60;
    return m == 0 ? '${h}h' : '${h}h${m.toString().padLeft(2, '0')}';
  }

  String? _getCleanBase64(String? base64Str) {
    if (base64Str == null || base64Str.isEmpty) return null;
    String clean = base64Str;
    if (clean.contains(',')) {
      clean = clean.split(',').last;
    }
    clean = clean.replaceAll(RegExp(r'\s+'), '');
    while (clean.length % 4 != 0) {
      clean += '=';
    }
    return clean.isEmpty ? null : clean;
  }
}
